# DevTrack 🚀
A beginner-friendly tech journey tracker inspired by the supplied NeoTracker idea.

## Stack
- Frontend: HTML, CSS, JavaScript
- Backend: Python + Django
- DevOps-ready: Git, Docker, GitHub Actions (next step)

## Run the frontend
Open `frontend/index.html` in a browser.

## Run Django
```bash
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python manage.py runserver
```

This starter intentionally keeps the architecture simple so you can understand and extend it.
