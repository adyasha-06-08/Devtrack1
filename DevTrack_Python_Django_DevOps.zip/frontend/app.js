const skills=[
{name:"Python",icon:"🐍",p:70},{name:"Web Tech",icon:"🌐",p:55},{name:"Django",icon:"🎯",p:35},{name:"DevOps",icon:"⚙️",p:25}];
const skillsEl=document.querySelector("#skills");
skillsEl.innerHTML=skills.map(s=>`<article class="card"><div class="icon">${s.icon}</div><h3>${s.name}</h3><div class="muted">Learning progress</div><div class="percent">${s.p}%</div><div class="bar"><div class="fill" style="width:${s.p}%"></div></div></article>`).join("");
const roadmap=["Python fundamentals & OOP","HTML • CSS • JavaScript","Django + database + APIs","Git • Docker • CI/CD • Deploy"];
document.querySelector("#roadmap").innerHTML=roadmap.map((x,i)=>`<div class="step"><small>STEP ${i+1}</small><div>${x}</div></div>`).join("");
document.querySelector("#date").textContent=new Date().toLocaleDateString(undefined,{day:"2-digit",month:"short",year:"numeric"});
let tasks=JSON.parse(localStorage.getItem("devtrack_tasks")||'["Learn Python OOP","Create Django project","Practice Git commands"]');
function render(){let done=tasks.filter(t=>t.done).length;document.querySelector("#done").textContent=done;document.querySelector("#total").textContent=tasks.length;document.querySelector("#tasks").innerHTML=tasks.map((t,i)=>`<div class="task ${t.done?"done":""}"><input type="checkbox" ${t.done?"checked":""} onchange="toggleTask(${i})"><span>${escapeHtml(t.text)}</span></div>`).join("");}
function toggleTask(i){tasks[i].done=!tasks[i].done;save();}
function save(){localStorage.setItem("devtrack_tasks",JSON.stringify(tasks));render();}
function escapeHtml(s){return s.replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));}
document.querySelector("#taskForm").addEventListener("submit",e=>{e.preventDefault();let v=document.querySelector("#taskInput").value.trim();if(v){tasks.push({text:v,done:false});document.querySelector("#taskInput").value="";save();}});
render();