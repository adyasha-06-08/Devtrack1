from pathlib import Path
BASE_DIR=Path(__file__).resolve().parent.parent
SECRET_KEY="devtrack-change-me"
DEBUG=True
ALLOWED_HOSTS=[]
INSTALLED_APPS=["django.contrib.contenttypes","django.contrib.staticfiles","tracker"]
MIDDLEWARE=["django.middleware.common.CommonMiddleware"]
ROOT_URLCONF="tracker.urls"
TEMPLATES=[{"BACKEND":"django.template.backends.django.DjangoTemplates","DIRS":[BASE_DIR/"tracker"/"templates"],"APP_DIRS":True,"OPTIONS":{"context_processors":[]}}]
WSGI_APPLICATION="tracker.wsgi.application"
STATIC_URL="static/"
STATICFILES_DIRS=[BASE_DIR/"tracker"/"static"]
